document.addEventListener("DOMContentLoaded", () => {
    // Veriler
    const books = [
        { id: 1, title: "Karamazov Kardeşler", available: true },
        { id: 2, title: "Savaş ve Barış", available: true },
        { id: 3, title: "Suç ve Ceza", available: false }
    ];

    const materials = [
        { id: 1, title: "Temizlik Bezi", available: true },
        { id: 2, title: "A4 Kağıdı", available: true },
        { id: 3, title: "Deterjan", available: true },
        { id: 4, title: "Tuvalet Kağıdı", available: false }
    ];

    const adminCredentials = {
        username: "admin",
        password: "admin123"
    };

    // Elementler
    const bookSelect = document.getElementById("book-select");
    const borrowBookBtn = document.getElementById("borrow-book-btn");
    const borrowMessage = document.getElementById("borrow-message");

    const reservationDate = document.getElementById("reservation-date");
    const reservationTime = document.getElementById("reservation-time");
    const reserveTableBtn = document.getElementById("reserve-table-btn");
    const reservationMessage = document.getElementById("reservation-message");

    const materialSelect = document.getElementById("material-select");
    const materialUse = document.getElementById("material-use");
    const materialMessage = document.getElementById("material-message");

    const adminLoginForm = document.getElementById("admin-login-form");
    const adminUsernameInput = document.getElementById("admin-username");
    const adminPasswordInput = document.getElementById("admin-password");
    const adminErrorMessage = document.getElementById("admin-error-message");

    // Fonksiyonlar
    function populateDropdown(selectElement, items, property) {
        selectElement.innerHTML = '<option value="">Bir seçenek seçin</option>';
        items.forEach(item => {
            const option = document.createElement("option");
            option.value = item.id;
            option.textContent = `${item[property]} ${item.available ? "(Mevcut)" : "(Stokta Yok)"}`;
            option.disabled = !item.available;
            selectElement.appendChild(option);
        });
    }

    function showMessage(element, message) {
        element.textContent = message;
        element.style.display = "block";
        setTimeout(() => {
            element.style.display = "none";
        }, 3000);
    }

    // Kitap Ödünç Alma
    borrowBookBtn.addEventListener("click", () => {
        const selectedBookId = parseInt(bookSelect.value, 10);
        const selectedBook = books.find(book => book.id === selectedBookId);

        if (selectedBook && selectedBook.available) {
            selectedBook.available = false;
            showMessage(borrowMessage, `"${selectedBook.title}" ödünç alındı!`);
            populateDropdown(bookSelect, books, "title");
        } else {
            alert("Geçerli bir kitap seçin!");
        }
    });

    // Masa Rezervasyonu
    reserveTableBtn.addEventListener("click", () => {
        const date = reservationDate.value;
        const time = reservationTime.value;

        if (date && time) {
            showMessage(reservationMessage, `Rezervasyon ${date} tarihinde, ${time} saatinde yapıldı!`);
        } else {
            alert("Lütfen tarih ve saat seçin!");
        }
    });

    // Malzeme Kullanımı
    materialUse.addEventListener("click", () => {
        const selectedMaterialId = parseInt(materialSelect.value, 10);
        const selectedMaterial = materials.find(material => material.id === selectedMaterialId);

        if (selectedMaterial && selectedMaterial.available) {
            showMessage(materialMessage, `"${selectedMaterial.title}" kullanıldı!`);
        } else {
            alert("Geçerli bir malzeme seçin!");
        }
    });

    // Yönetici Girişi
    adminLoginForm.addEventListener("submit", (e) => {
        e.preventDefault();
        const username = adminUsernameInput.value;
        const password = adminPasswordInput.value;

        if (username === adminCredentials.username && password === adminCredentials.password) {
            alert("Giriş başarılı!");
            window.location.href = "admin-dashboard.html";
        } else {
            showMessage(adminErrorMessage, "Kullanıcı adı veya şifre hatalı!");
        }
    });

    // Dropdownları doldur
    populateDropdown(bookSelect, books, "title");
    populateDropdown(materialSelect, materials, "title");
});

document.addEventListener('DOMContentLoaded', () => {
    const memberLoginButton = document.getElementById('member-login');
    if (memberLoginButton) {
        memberLoginButton.addEventListener('click', () => {
            const email = prompt('E-posta:');
            const password = prompt('Şifre:');

            fetch('member_login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Üye girişi başarılı!');
                    window.location.href = 'member-dashboard.php';
                } else {
                    alert('Giriş başarısız: ' + data.message);
                }
            })
            .catch(error => console.error('Hata:', error));
        });
    }

    const adminLoginButton = document.getElementById('admin-login');
    if (adminLoginButton) {
        adminLoginButton.addEventListener('click', () => {
            const email = prompt('E-posta:');
            const password = prompt('Şifre:');

            fetch('admin_login.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Personel girişi başarılı!');
                    window.location.href = 'admin-dashboard.php';
                } else {
                    alert('Giriş başarısız: ' + data.message);
                }
            })
            .catch(error => console.error('Hata:', error));
        });
    }
});
