<?php
header('Content-Type: application/json'); // JSON formatında yanıt döndürme
include('baglanti.php');
$data = json_decode(file_get_contents("php://input"));

$email = $data->email;
$password = $data->password;

$query = "SELECT * FROM uye WHERE email = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    if (password_verify($password, $user['sifre'])) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => "E-posta veya şifre hatalı!"]);
    }
} else {
    echo json_encode(["success" => false, "message" => "E-posta veya şifre hatalı!"]);
}
$stmt->close();
$conn->close();
?>

header('Content-Type: application/json'); // JSON formatında yanıt döndürme
include('baglanti.php');

$query = "SELECT * FROM uye";
$result = $conn->query($query);

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}

echo json_encode(["success" => true, "data" => $data]);

$conn->close();
?>
